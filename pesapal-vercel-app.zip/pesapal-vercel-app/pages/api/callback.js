export default async function handler(req, res) {
  console.log('PesaPal Callback Received:', req.query);
  res.status(200).send("Thank you! Payment processed.");
}
